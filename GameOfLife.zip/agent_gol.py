from mesa import Agent

class GameOfLife(Agent):
    def __init__(self, pos, model):
        super().__init__(pos, model)
        self.pos = pos
        self.condition = "Alive"
    
    def step(self):
        count = 0
        for neighbor in self.model.grid.neighbor_iter(self.pos):
            if(neighbor.condition == "Alive"):
                count += 1
        if(self.condition=="Alive" and (count>=4 or count<2)):
            self.condition = "Dead"
        elif(self.condition=="Dead" and count==3):
            self.condition = "Alive"